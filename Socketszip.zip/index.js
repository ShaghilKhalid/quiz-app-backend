const express = require('express') //NOT
const http = require('http')
const socketio = require('socket.io')
const mysql = require("mysql2");
var bodyParser = require('body-parser');
require("events").EventEmitter.defaultMaxListeners = 20;

const conn = mysql
    .createConnection({
        host: "localhost", // HOST NAME
        user: "root", // USER NAME
        database: "multivendor", // DATABASE NAME
        password: "", // DATABASE PASSWORD
    }).promise()
    .on("error", (err) => {
console.log(err)
    });
const PORT = 5000 //NOT
const app = express() //NOT

const server = http.createServer(app)
const io = socketio(server,{
    transport:["polling"],
    cors:{
        origin : "*",
        
    }
})
app.use(express.json()) //NOT
app.use(bodyParser.json()); //NOT


const notification = io.of('/notification')
const chat = io.of('/chat')


notification.on("connection",async (socket)=>{
    
    
    var [rows2] = await conn.execute('SELECT * FROM notifications')

    socket.on("notifications",async (data)=>{
        const [rows] = await conn.execute("Insert into notifications (`description`) value(?)",[data])
       var [rows2] = await conn.execute('SELECT * FROM notifications')
        socket.broadcast.emit("receive_message",rows2)
    })
    socket.emit("receive_message",rows2)
    socket.emit('rows',rows2)
    
})




chat.on("connection",(socket)=>{
    console.log(socket.id)
    socket.on("join_room", recipientId=>{
        socket.join(recipientId)
        
    })
    socket.on("send_message",async(sender_id,recipient_id,message)=>{
        var date = new Date()
        console.log(sender_id,recipient_id,message)
        // const [rows] = await conn.execute("INSERT INTO messages (`content`,`sender_id`,`recipient_id`,`time_sent`) VALUES(?,?,?,?)",[
        //     message,
        //     sender_id,
        //     recipient_id,
        //     date
        // ])
        
    })
    socket.on("get_all_messages",async(sender_id,recipientId)=>{
    //   const [message] = await  conn.execute("SELECT * FROM messages where (sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?)",[
    //         sender_id,
    //         recipientId,
    //         recipientId,
    //         sender_id
    //     ])
        // console.log(message)
        // socket.emit("messages",message)
    })
})



server.listen(PORT,()=>{ //NOT
    console.log("Server listening on port",PORT) //NOT
})//NOT
